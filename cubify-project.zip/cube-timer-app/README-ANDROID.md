# Cubify: build the Android app (APK)

I wrote these steps and files but could not run them: the environment I work in has no
internet and no Android SDK, so the **APK itself has never been built**. The app page
(`www/index.html`) was run and tested in a real headless Chromium browser at phone size. If a step shows an
error, copy the error message and send it back.

## What is in this folder

| Path | What it is |
|---|---|
| `www/index.html` | The whole app |
| `www/fonts/` | Put the four font files here (step 2) |
| `assets/` | Cubify icon (pixel Rubik's cube on gray) and splash screen pictures |
| `tools/make_icons.py` | Redraws the icon pictures if you want to change them |
| `capacitor.config.json` | App name (Cubify), app ID and network settings |
| `package.json` | Lists the tools to install |
| `docs/message-schema.md` | The message format for the ESP32 firmware |

## Easiest: build it online with GitHub (nothing to install)

GitHub can build the APK on its own servers. This recipe (`.github/workflows/build-apk.yml`)
was written but **not yet run**, so the first build may need a fix. If it fails, open the red
run, copy the error text and send it to me.

1. Create a free account at github.com, then a **new repository**. Choose **Private**.
2. In the repository, tap **Add file, then Upload files**, and upload `cubify-project.zip` as it is (do not unzip it). Commit.
3. Tap **Add file, then Create new file**. In the name box type exactly `.github/workflows/build-apk.yml`. Paste the contents of `build-apk.yml` (it is next to this zip) into the big box. Commit.
4. Open the **Actions** tab. A run named **Build Cubify APK** starts by itself. If it does not, tap it on the left, then **Run workflow**.
5. Wait until it shows a green check. Open the run, scroll to **Artifacts**, and download **Cubify-debug-apk**. It is a zip with `app-debug.apk` inside.
6. Unzip it, open `app-debug.apk` on your phone, and allow the install.

The fonts are not in the zip. To bundle them, add the four font files to `www/fonts/` before zipping,
or ignore this: the app then uses your phone's normal font when it has no internet.

## Or build on your own computer

### 1. Install the tools (once)

1. **Node.js** (LTS version) from nodejs.org.
2. **Android Studio** from developer.android.com/studio. Open it once and let it install the Android SDK.
3. **Python 3 and Pillow** are only needed to redraw the icon: `pip install pillow`. The finished icon pictures are already in `assets/`, so you can skip this.

### 2. Add the fonts (once)

Download **Poppins** and **Pixelify Sans** from fonts.google.com and copy these four files into `www/fonts/`:

```
Poppins-Regular.ttf
Poppins-SemiBold.ttf
Poppins-Bold.ttf
PixelifySans-VariableFont_wght.ttf
```

If the file names are a bit different, rename them to match. Without these files the app still
works, but it uses your phone's normal font when there is no internet.

### 3. Build

Open a terminal in the `cube-timer-app` folder and run:

```
npm install
npx cap add android
npx @capacitor/assets generate --android
npx cap sync android
npx cap open android
```

What each line does: installs the tools, creates the Android project, makes every icon size
from the pictures in `assets/`, copies the app into the Android project, and opens Android Studio.

### 4. Make the APK

In Android Studio, wait for the project to finish loading, then:
**Build, then Build APK(s)**. When it finishes, click **locate**. The file is usually
`android/app/build/outputs/apk/debug/app-debug.apk`. Your phone will show the name **Cubify**
with the pixel cube icon.

### 5. Install on your phone

1. Copy `app-debug.apk` to your phone (USB cable, cloud drive or Bluetooth).
2. Tap it. Android will ask to allow installing apps from this source. Allow it for the app you opened the file with.
3. Open Cubify.

This is a personal "debug" build. It is fine for your own phone. Publishing on the Play Store would need a signed release build, which is a separate step.

## After you change `www/index.html`

```
npx cap sync android
```
then build the APK again in Android Studio (or press Run with the phone connected).

## Settings to know about

- **`androidScheme: "http"` and `cleartext: true`** let the app talk to the ESP32 over plain `ws://`. With the default `https` setting, Android would block that connection.
- **Do not change `androidScheme` later.** Your saved solves, categories and background live under that address. Changing it makes them disappear from the app. Export a CSV first if you ever need to change it.
- I wrote these option names from my knowledge of the Capacitor documentation and could not check them against your installed version. If `npx cap sync` complains about an unknown option, send me the message.
- The app ID `com.cubify.app` can be changed before the first build. Do not change it after you install.

## Not included yet

- **Bluetooth timer.** Android's app view does not include Web Bluetooth, so connecting the QiYi timer will need a Bluetooth plugin added here.
- **Saving CSV and picture picking inside the app.** Both may need small Capacitor plugins (Share and Filesystem). We will test them on your phone first. The picture picker problem from earlier may disappear in the installed app.
- **Storage.** Solves are kept in the app's web storage, which holds roughly 10,000 to 15,000 solves.

## Test list after installing

| Check | Expected |
|---|---|
| App name and icon on the home screen | Cubify with the pixel cube on gray |
| Open the app with Wi-Fi off | It opens and shows saved solves |
| Settings, enter the ESP32 address, Connect | Shows Connected (needs the firmware, not written yet) |
| Phone timer, time a solve | Solve appears in History |
| Close and reopen | Solves and settings are still there |
| Background tab, Choose picture | The Android picture chooser opens |
| Export, Save or share CSV | Share sheet or a saved file |


## Bluetooth (ESP32, GAN timers)

- **Plugin:** `@capacitor-community/bluetooth-le` is in `package.json`, so the GitHub build installs it and adds the Bluetooth permissions on its own. On Android 12 and newer the app asks for "Nearby devices" the first time you search.
- **ESP32:** Settings, set the connection to Bluetooth, wake the timer (tap the red button), tap **Find my ESP32 timer**. Test it first with `firmware/cubify_ble_test.ino`.
- **GAN timer:** Settings, **Connect GAN timer**. Untested on real hardware. If it does not work, use the recorder box (it logs every packet), copy the log and send it.
- **QiYi timer:** not supported yet. Use the recorder, copy the log and send it.
- The message format is in `docs/message-schema.md`, section 8.
- None of the Bluetooth code has run on a phone or on real timers yet. It was tested in a browser with fake devices only.
