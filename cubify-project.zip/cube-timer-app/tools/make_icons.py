"""Builds every Cubify icon from assets/logo-source.png (the green/red cube logo).
Run:  python3 tools/make_icons.py     (needs: pip install pillow)
Writes the files @capacitor/assets expects into ./assets, and web icons into ./web-icons"""
from PIL import Image
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, "assets"); WEB = os.path.join(ROOT, "web-icons")
os.makedirs(WEB, exist_ok=True)
logo = Image.open(os.path.join(A, "logo-source.png")).convert("RGB")
sq = lambda n: logo.resize((n, n), Image.LANCZOS)
# Android adaptive icon: the logo fills both layers; the cube sits inside the 66% safe zone
sq(1024).save(os.path.join(A, "icon-background.png"))
sq(1024).convert("RGBA").save(os.path.join(A, "icon-foreground.png"))
sq(1024).save(os.path.join(A, "icon-only.png"))
# Splash: logo centred on its own dark edge colour
bg = (8, 8, 10)
for name in ("splash.png", "splash-dark.png"):
    s = Image.new("RGB", (2732, 2732), bg); l = sq(1100); s.paste(l, ((2732 - 1100) // 2,) * 2); s.save(os.path.join(A, name))
# Web / PWA icons
sq(192).save(os.path.join(WEB, "icon-192.png")); sq(512).save(os.path.join(WEB, "icon-512.png"))
sq(180).save(os.path.join(WEB, "apple-touch-icon.png"))
m = Image.new("RGB", (512, 512), bg); inner = sq(410); m.paste(inner, (51, 51)); m.save(os.path.join(WEB, "maskable-512.png"))
print("done")
