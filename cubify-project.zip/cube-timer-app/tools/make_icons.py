"""Draws the Cubify icon: the same pixelated Rubik's cube used in the app, on a gray background.
Run:  python3 tools/make_icons.py     (needs: pip install pillow)
Writes the files @capacitor/assets expects into ./assets"""
from PIL import Image, ImageDraw
import os

GRAY = (44, 48, 56, 255)          # icon background (darker gray)
OUTLINE = (8, 8, 10, 255)         # cube body and outline
COL = {"U": (242, 242, 242), "D": (245, 208, 0), "F": (31, 163, 74),
       "B": (31, 95, 208), "R": (216, 49, 43), "L": (242, 133, 28)}   # same colors as the app
SCRAMBLE = "D B D' F2 R F U B L F D' L' B D' F2 U2 B2 U' B L2"        # the scramble from the TFT screenshot
K = 11                            # pixels per cube unit in the low-resolution sprite (like the app's pixelated cube)

# --- tiny 3x3 cube simulator, same logic as the app ---
ROT = {"x": lambda v: (v[0], -v[2], v[1]), "y": lambda v: (v[2], v[1], -v[0]), "z": lambda v: (-v[1], v[0], v[2])}
FACE = {"U": ("y", 1, -1), "D": ("y", -1, 1), "R": ("x", 1, -1), "L": ("x", -1, 1), "F": ("z", 1, -1), "B": ("z", -1, 1)}

def new_cube():
    s = []
    for x in (-1, 0, 1):
        for y in (-1, 0, 1):
            for z in (-1, 0, 1):
                if x: s.append({"p": (x, y, z), "n": (x, 0, 0), "c": "R" if x > 0 else "L"})
                if y: s.append({"p": (x, y, z), "n": (0, y, 0), "c": "U" if y > 0 else "D"})
                if z: s.append({"p": (x, y, z), "n": (0, 0, z), "c": "F" if z > 0 else "B"})
    return s

def turn(cube, face, q):
    ax, side, sg = FACE[face]
    i = "xyz".index(ax)
    times = q if sg > 0 else (3 * q) % 4
    for s in cube:
        if s["p"][i] == side:
            for _ in range(times):
                s["p"] = ROT[ax](s["p"]); s["n"] = ROT[ax](s["n"])

def apply(cube, scramble):
    for t in scramble.split():
        face, mod = t[0], t[1:]
        turn(cube, face, 2 if mod == "2" else 3 if mod == "'" else 1)

def proj(v):
    return ((v[0] - v[2]) * 0.866, -v[1] + (v[0] + v[2]) * 0.5)

def sprite():
    """The cube as a small low-resolution RGBA picture: black cube body, colored stickers, hard pixel edges."""
    cube = new_cube(); apply(cube, SCRAMBLE)
    w, h = int(2 * 3 * 0.866 * K) + 9, int(2 * 3 * K) + 9
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    cx, cy = w / 2, h / 2
    def quad(s, half):
        n = s["n"]; c = [s["p"][k] + n[k] * 0.5 for k in range(3)]
        ax = [k for k in range(3) if n[k] == 0]; u = [0, 0, 0]; v = [0, 0, 0]
        u[ax[0]] = half; v[ax[1]] = half
        pts = []
        for a, b in ((1, 1), (1, -1), (-1, -1), (-1, 1)):
            q = proj([c[k] + u[k] * a + v[k] * b for k in range(3)])
            pts.append((cx + q[0] * K, cy + q[1] * K))
        return pts
    vis = [s for s in cube if sum(s["n"]) == 1]
    for s in vis: d.polygon(quad(s, 0.555), fill=OUTLINE)      # bold outline: the black body sticks out past the stickers
    for s in vis: d.polygon(quad(s, 0.39), fill=COL[s["c"]] + (255,))   # smaller stickers = thicker black lines between them
    return img

def big(sp, scale):
    return sp.resize((sp.width * scale, sp.height * scale), Image.NEAREST)   # NEAREST keeps the pixels square and sharp

def place(canvas, sp):
    canvas.alpha_composite(sp, ((canvas.width - sp.width) // 2, (canvas.height - sp.height) // 2))
    return canvas

def main():
    out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets"); os.makedirs(out, exist_ok=True)
    sp = sprite()
    cube9 = big(sp, 8)                                         # stays inside Android's adaptive-icon safe zone
    Image.new("RGBA", (1024, 1024), GRAY).convert("RGB").save(os.path.join(out, "icon-background.png"))
    place(Image.new("RGBA", (1024, 1024), (0, 0, 0, 0)), cube9).save(os.path.join(out, "icon-foreground.png"))
    place(Image.new("RGBA", (1024, 1024), GRAY), cube9).convert("RGB").save(os.path.join(out, "icon-only.png"))
    for name in ("splash.png", "splash-dark.png"):
        place(Image.new("RGBA", (2732, 2732), GRAY), big(sp, 11)).convert("RGB").save(os.path.join(out, name))
    print("wrote", sorted(os.listdir(out)))

main()
