// Cubify timer - STEP 2: Bluetooth link test (no screen needed, only the ESP32)
// Board: "ESP32 Dev Module"     Library: "NimBLE-Arduino" by h2zero, version 2.x (Library Manager)
//
// What it does: advertises as "Cubify-TEST", answers the app's hello with welcome + syncDone,
// and sends a fake solve every time you press the BOOT button (GPIO 0). Use it to check that the
// app connects, syncs, and keeps solves without doubles. It stores nothing: restart = start over.
// Messages follow docs/message-schema.md section 8.

#include <NimBLEDevice.h>

#define SVC_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define RX_UUID  "6e400002-b5a3-f393-e0a9-e50e24dcca9e"   // app writes here
#define TX_UUID  "6e400003-b5a3-f393-e0a9-e50e24dcca9e"   // we notify here
#define PIN_BOOT 0

NimBLECharacteristic* tx;
bool connected = false;
String rxBuf;
uint32_t nextId = 1, cs = 0, seqNo = 1;
uint32_t lastCsSeen = 0;

// Sends one JSON line in pieces that fit the current MTU (at least 20 bytes)
void sendLine(const String& s) {
  if (!connected) return;
  String line = s + "\n";
  const size_t piece = 20;
  for (size_t i = 0; i < line.length(); i += piece) {
    String part = line.substring(i, i + piece);
    tx->setValue((const uint8_t*)part.c_str(), part.length());
    tx->notify();
    delay(8);
  }
}

void sendFakeSolve() {
  uint32_t ms = 8000 + (esp_random() % 6000);
  uint32_t id = nextId++;
  cs++;
  String m = "{\"type\":\"solve\",\"id\":" + String(id) + ",\"cs\":" + String(cs) +
             ",\"rev\":1,\"ms\":" + String(ms) + ",\"penalty\":\"none\",\"puzzle\":\"3x3\",\"category\":\"Default\"," +
             "\"scramble\":\"R U R' U'\",\"note\":\"\",\"ts\":0,\"et\":0,\"deleted\":false}";
  sendLine(m);
  Serial.printf("sent fake solve #%u (%u ms)\n", id, ms);
}

void handleLine(const String& l) {
  Serial.println("app: " + l);
  if (l.indexOf("\"type\":\"hello\"") >= 0) {
    int p = l.indexOf("\"lastCs\":");
    lastCsSeen = p >= 0 ? l.substring(p + 9).toInt() : 0;
    sendLine("{\"type\":\"welcome\",\"v\":1,\"device\":\"Cubify-TEST\",\"fw\":\"test\",\"boot\":\"t1\",\"timeSynced\":true,\"solveCount\":0,\"pending\":0}");
    sendLine("{\"type\":\"syncDone\",\"count\":0,\"lastCs\":" + String(cs) + "}");
  } else if (l.indexOf("\"type\":\"ping\"") >= 0) {
    int p = l.indexOf("\"t\":");
    sendLine("{\"type\":\"pong\",\"t\":" + String(p >= 0 ? l.substring(p + 4).toInt() : 0) + "}");
  }
}

class RxCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo& info) override {
    std::string v = c->getValue();
    for (char ch : v) {
      if (ch == '\n') { if (rxBuf.length()) handleLine(rxBuf); rxBuf = ""; }
      else if (rxBuf.length() < 1536) rxBuf += ch;
    }
  }
};
class SrvCb : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer*, NimBLEConnInfo&) override { connected = true; rxBuf = ""; Serial.println("phone connected"); }
  void onDisconnect(NimBLEServer*, NimBLEConnInfo&, int) override {
    connected = false; Serial.println("phone disconnected"); NimBLEDevice::startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  pinMode(PIN_BOOT, INPUT_PULLUP);
  NimBLEDevice::init("Cubify-TEST");
  NimBLEServer* srv = NimBLEDevice::createServer();
  srv->setCallbacks(new SrvCb());
  NimBLEService* svc = srv->createService(SVC_UUID);
  tx = svc->createCharacteristic(TX_UUID, NIMBLE_PROPERTY::NOTIFY);
  NimBLECharacteristic* rx = svc->createCharacteristic(RX_UUID, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  rx->setCallbacks(new RxCb());
  svc->start();
  NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
  adv->addServiceUUID(SVC_UUID);
  adv->start();
  Serial.println("Advertising as Cubify-TEST. Press BOOT to send a fake solve.");
}

void loop() {
  static bool was = false;
  bool now = digitalRead(PIN_BOOT) == LOW;
  if (now && !was) sendFakeSolve();
  was = now;
  delay(20);
}
