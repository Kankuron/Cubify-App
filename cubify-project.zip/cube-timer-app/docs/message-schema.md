# Cubify message format (protocol v1)

The ESP32 firmware and the phone app talk over one WebSocket using JSON messages.
This file is the contract between them. **Status:** the app side is implemented and
tested against these examples. The firmware side is not written yet, so nothing here
has been tested against real hardware.

## 1. Transport

| Item | Value |
|---|---|
| Connection | WebSocket, `ws://<esp32-ip>:81/` (plain, same Wi-Fi network only) |
| Frames | One JSON object per text frame, UTF-8 |
| Max frame size | 1536 bytes (the firmware JSON buffer is 2048 bytes) |
| Direction | Both ways. The ESP32 is the source of truth for the live timer and for solve numbering |
| Several phones | The ESP32 sends `state`, `solve` and `settings` to every connected client |

Every message has a string field `type`. Unknown types are ignored by the app and
answered with `error` (`unknown_type`) by the firmware. Unknown extra fields are ignored.

## 2. Conventions

| Term | Meaning |
|---|---|
| Time values | Epoch milliseconds in UTC (`ts`, `et`, `time`). Display uses the phone's time zone |
| `ms` | Raw solve time in milliseconds, integer, 0 to 36000000. The penalty is stored separately |
| `penalty` | `"none"`, `"+2"` or `"DNF"` |
| `puzzle` | `"2x2"`, `"3x3"` or `"4x4"` |
| `category` | Text, 1 to 24 characters. The category list lives on the phone, the ESP32 only stores the name with each solve |
| `scramble` | Text, up to 400 characters, moves separated by spaces (`R U R' U'`, 4x4 also `Rw`) |
| `note` | Text, up to 300 characters |
| `id` | Whole number given by the ESP32, starts at 1, increases, never reused |
| `rev` | Revision of one solve. Starts at 1, goes up by 1 on every edit (penalty, note, delete) |
| `et` | Time of the last edit (epoch ms). Used only to break ties between equal `rev` values |
| `cs` | Change counter. One global counter on the ESP32, goes up on every new solve and every edit. Each solve carries the `cs` of its last change |
| `seq` | Counter on `state` messages. Goes up with each state message so old ones can be dropped |
| `pid` | Temporary ID (text, up to 24 characters) for a solve timed on the phone |

The ESP32 has no clock. It sets its clock from `hello.time` and then adds elapsed
`millis()`. Until it has received a `hello`, it sends `"ts": 0` and the app uses the time
the solve arrived instead. Times can drift by a few seconds over days. They are not for scoring.

## 3. Connection sequence

```
App                                   ESP32
 | -- hello {lastCs, time, pin?} -->    |
 | <-- welcome {device, boot, ...} --   |
 | <-- settings {puzzle, category...}   |   (current device settings)
 | <-- state {seq, status, ...} -----   |   (current timer state)
 | <-- solve {cs > lastCs} ... -----    |   (oldest change first)
 | -- ack {id, rev, cs} ----------->    |   (one per solve; the ESP32 may send the next batch after the ack for the last solve of a batch of 20)
 | <-- syncDone {count, lastCs} ----    |
 | -- settings {...} --------------->   |   (the app's puzzle/category/inspection)
 | -- edit / phoneSolve (queued) --->   |
 | <-- ack / solve ------------------   |
 | -- ping {t} -- every 20 s ------->   |
 | <-- pong {t} ---------------------   |
```

The app treats the connection as lost if nothing arrives for 45 seconds, then reconnects
every 3 seconds. After every reconnect it repeats `hello`, so a dropped connection never
creates duplicate solves: the app only asks for changes newer than its saved `lastCs`.

## 4. Messages from the app to the ESP32

### `hello`
```json
{"type":"hello","v":1,"lastCs":41,"time":1792915200000,"pin":"4821"}
```
| Field | Required | Notes |
|---|---|---|
| `v` | yes | Protocol version, `1` |
| `lastCs` | yes | Highest `cs` the app has stored. `0` for a fresh install. The ESP32 sends every solve with a higher `cs` |
| `time` | yes | Phone time, epoch ms, so the ESP32 can set its clock |
| `pin` | only if the app has one | Must match the PIN in the firmware's `secrets.h`. Wrong or missing PIN gives `error` with code `auth`, and the ESP32 closes the connection |

### `settings`
```json
{"type":"settings","inspection":"before","puzzle":"3x3","category":"Practice"}
```
`inspection` is `"off"`, `"before"` (15 s countdown before each solve) or `"only"`
(countdown without timing the solve). The ESP32 applies it and sends `settings` to the
other clients. New solves are tagged with this puzzle and category.

### `edit`
```json
{"type":"edit","id":17,"rev":2,"penalty":"+2","note":"R U R' U'","deleted":false,"et":1792915300000}
```
The ESP32 applies it if `rev` is higher than its own, or equal with a later `et`.
It answers `ack` with the same `id` and `rev`, and sends the changed solve to the other
clients. If its own revision is newer it ignores the edit, answers `ack` with its own `rev`,
and sends the solve so the app updates. `deleted: true` keeps the record as a hidden
solve until the app has acknowledged it (see section 6).

### `phoneSolve`
A solve the phone timed itself (Phone timer mode).
```json
{"type":"phoneSolve","pid":"lq3x9k2a1b","ms":9420,"penalty":"none","puzzle":"3x3","category":"Practice","scramble":"R U R' U' F2","note":"","ts":1792915200000,"rev":1,"et":0,"deleted":false}
```
The ESP32 stores it with a new `id`, then sends `solve` containing the same `pid`.
The app replaces its temporary ID with `id`. **If the ESP32 already has that `pid`, it must
not store it again** and just sends the existing solve. The app re-sends every phone-only
solve on each connect until it gets that answer.

### `ack`
```json
{"type":"ack","id":17,"rev":1,"cs":42}
```
The app has stored that solve and revision. The ESP32 may then mark it as synced.

### `ping`
```json
{"type":"ping","t":1792915200000}
```

## 5. Messages from the ESP32 to the app

### `welcome`
```json
{"type":"welcome","v":1,"device":"cubetimer-a1b2c3","fw":"1.0.0","boot":"8f3a1c","timeSynced":true,"solveCount":120,"pending":3}
```
`boot` changes on every restart. `pending` is how many solves with `cs > lastCs` will follow.
The app resets its `seq` check when it sees `welcome`.

### `state`
```json
{"type":"state","seq":812,"status":"running","elapsedMs":3150,"scramble":"R U R' U' F2","puzzle":"3x3","category":"Practice"}
```
| `status` | Meaning |
|---|---|
| `idle` | Ready for a new solve |
| `inspecting` | Inspection countdown running, `elapsedMs` counts up from 0 |
| `holding` | Screen is being held, not ready yet |
| `ready` | Held long enough, release to start |
| `running` | Solve running, `elapsedMs` is the time at the moment the message was sent |
| `stopped` | Solve finished, `elapsedMs` is the final raw time |

The app counts up on its own between messages and corrects itself with every `state`.
It is never the authority. The ESP32 sends `state` on every status change, and while
`running` or `inspecting` at least once per second so the app stays in step. It
includes `scramble` whenever it changes. The app ignores a `state` whose `seq` is not higher
than the last one it saw since the last `welcome`.

### `solve`
```json
{"type":"solve","id":17,"cs":42,"rev":1,"ms":9420,"penalty":"none","puzzle":"3x3","category":"Practice","scramble":"R U R' U' F2","note":"","ts":1792915200000,"et":0,"deleted":false}
```
Sent for every new solve, every changed solve, and during the sync after `hello`. For a
phone-timed solve the ESP32 adds `"pid"`. If the app already has this `id` the message is
used only when `rev` is higher, or equal with a later `et`. The app answers every `solve` with `ack`.

### `syncDone`
```json
{"type":"syncDone","count":3,"lastCs":45}
```
End of the catch-up after `hello`. `count` is how many solves were sent.

### `settings`
Same fields as the app's `settings`. Sent after `welcome`, and again whenever puzzle,
category or inspection is changed on the TFT. The app follows it, and adds the category
to its list if it is new.

### `ack`
```json
{"type":"ack","id":17,"rev":2}
```
Answer to `edit`. The app then removes that edit from its waiting list.

### `pong`
```json
{"type":"pong","t":1792915200000}
```

### `error`
```json
{"type":"error","code":"bad_value","msg":"penalty must be none, +2 or DNF","ref":"edit"}
```
| `code` | Meaning |
|---|---|
| `auth` | Missing or wrong PIN. The connection is closed |
| `bad_json` | Frame could not be parsed or was too large |
| `unknown_type` | Message type not known |
| `bad_value` | A field is missing or out of range |
| `not_found` | Edit refers to an `id` the ESP32 does not have |
| `busy` | The ESP32 cannot take this right now, try again |

## 6. Sync rules

1. **The ESP32 numbers every solve.** The phone never invents numeric IDs. Phone-timed solves wait with a `pid` until the ESP32 answers.
2. **Changes, not just new solves.** Because every new solve and edit bumps `cs`, one number (`lastCs`) is enough to catch up on both.
3. **Conflicts.** The higher `rev` wins. Equal `rev`: the later `et` wins. Equal `et`: the ESP32's version wins.
4. **Deletes** are hidden records with `deleted: true`. The ESP32 may remove a hidden record from flash only after the app has sent `ack` for that `rev`. The app keeps hidden records too.
5. **Edits while offline** wait on the phone and are sent after the next `hello`. The ESP32 must answer each one.
6. **Reboot and power loss.** A solve that was running is lost. Finished solves are written to flash when the solve stops, together with the `id` counter and `cs`, so numbering continues after a restart.
7. **Flash wear.** Write once per finished solve and once per edit. Never write on every `state` message.

## 7. Security

- Version 1 runs on a trusted home network only. Do not forward the port to the internet.
- The optional PIN keeps other people on the same Wi-Fi from editing your solves. It is sent as plain text, so it is not strong security. The app stores it unencrypted on the phone.
- Keep the Wi-Fi name, Wi-Fi password and PIN in a `secrets.h` file that is not shared or published.
- The ESP32 must check every field before using it and answer `error` for anything invalid. It must never crash on bad input.

## 8. Not in version 1

- Remote start, stop or reset of the timer from the app. The app only watches the live timer.
- Encryption (`wss://`) and accounts.
- Compressing old history on the ESP32. Capacity is limited by flash, plan for a few thousand solves.

## 9. Protocol test checklist

| Test | Expected result |
|---|---|
| Fresh app, `hello` with `lastCs: 0` | `welcome`, `settings`, `state`, every stored solve, then `syncDone` |
| Reconnect with no new solves | `welcome`, `state`, `syncDone` with `count: 0`, no duplicate solves in the app |
| Solve on the TFT while the app is connected | `state` changes to `running` then `stopped`, then a `solve`, app answers `ack` |
| Solve on the TFT while the app is away | After reconnect the solve arrives once |
| Change penalty in the app | `edit` then `ack`; the TFT history shows the new penalty |
| Change penalty on the TFT | `solve` with higher `rev` reaches the app |
| Same solve edited on both sides while offline | Both sides end with the same value (rule 3) |
| Delete in the app | Hidden on both sides, not counted in stats |
| Phone-timed solve, then connect | `phoneSolve`, then `solve` with the same `pid`; the app shows a numeric ID |
| Send `phoneSolve` twice | Stored once |
| Wrong PIN | `error` `auth`, connection closed, app shows "Wrong PIN" |
| Send garbage JSON | `error` `bad_json`, connection stays up |
| Unplug the ESP32 | App shows Reconnecting, then Connected after power returns |
